function [LHS, RHS] = OST(theta, timestep, M, B, C, sol) %Kapitel6的13页
% theta=0.5
% timestep=0.2
% M=[1.1]
% B=[1.4,1.5]
% C=[1.6,1.7]
% sol=[2.0]
if size(M) == 1
    LHS = M - theta * timestep * B(1);
    RHS = (M + (1 - theta) * timestep * B(2)) * sol + timestep * (theta * C(1) + (1 - theta) * C(2));
else
    LHS = M - theta * timestep * B;
    RHS = (M + (1 - theta) * timestep * B) * sol + timestep * (theta * C + (1 - theta) * C);
end 