function [LHS, RHS] = BDF2(timestep, M, B, C, sol)
% timestep = 0.2
% M = [1.1]
% B = [1.4]
% C = [1.7]
% sol = [2.0,2.1]
LHS = 3/2 * M - timestep * B;
RHS = 2 * M * sol(1) - 1/2 * M * sol(2) + timestep * C;
end
