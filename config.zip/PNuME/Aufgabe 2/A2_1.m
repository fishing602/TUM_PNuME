clc;
clear all;
close all;

%%

x_1 = 0.0;
y_1 = 1.0;

delta = logspace(-20, 5, 1000);
x_2 = delta;
y_2 = 1.0 + delta;


epsilon = 2*10^(-16);
x_ex = 1;
x_num = (x_2 - x_1) / (y_2 - y_1);

X1 = abs(x_ex - x_num);%看一下讲义04第11页
X2 = abs(epsilon ./ (delta +epsilon));
X3 = abs(-epsilon ./ (delta - epsilon));

% 用loglog以log坐标来画坐标
loglog(delta,X1,'b')
hold on

loglog(delta,X2,'g')
hold on

loglog(delta,X3,'r--')
hold on

xlabel('delta')
ylabel('AbsoluteFehler |x_ex - x_num|')
legend({'abs Fehler','epsilon/(delta+epsilon)','-epsilon/(delta+epsilon)'})
grid on

